package Lab7;

public class EmployeeList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
