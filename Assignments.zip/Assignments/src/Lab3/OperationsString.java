package Lab3;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;

/**
 * @author subhojit
 *
 */
public class OperationsString {

	private String text = "Initial String";

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public void concatinationOfString(String text) {
		String newString = this.text + " " + text;
		setText(newString);
	}
	public String removeDuplicates(String input){
	    String result = "";
	    for (int i = 0; i < input.length(); i++) {
	        if(!result.contains(String.valueOf(input.charAt(i)))) {
	            result += String.valueOf(input.charAt(i));
	        }
	    }
	    return result;
	}

	public static void main(String[] args) throws NumberFormatException, IOException {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		System.out.println(
				"1--> CONCATINATION\n2-->REPLACE ODD POSITION WITH #\n3-->REMOVE DUPLICATE\n4-->CHANGE UPPER CASE OF ODD POSITION");
		int ch = Integer.parseInt(br.readLine());
		TreeSet uniqueElements=new TreeSet();
		OperationsString operationString = new OperationsString();
		switch (ch) {
		case 1: // contacatination

			System.out.println("Enter string to be concatinated");
			String concatString = br.readLine();
			System.out.println("Text Before: " + operationString.getText());
			operationString.concatinationOfString(concatString);
			System.out.println("New text is: " + operationString.getText());
			break;
		case 2:
			System.out.println("Enter your TEXT ");
			operationString.setText(br.readLine());
			String modification = operationString.getText();
			char stringArray[] = modification.toCharArray();
			int size = stringArray.length;
			for (int position = 1; position < size; position += 2) {
				stringArray[position] = '#';
				modification = String.valueOf(stringArray);
			}
			System.out.println("Before Modification: " + operationString.getText());
			operationString.setText(modification);
			System.out.println("Modified String is: " + operationString.getText());
			break;
		case 4:
			System.out.println("Enter your TEXT ");
			operationString.setText(br.readLine());
			String modificationText = operationString.getText();
			char stringArrayText[] = modificationText.toCharArray();
			int sizeOfString = stringArrayText.length;
			for(int pos=0; pos<sizeOfString; pos++){
				char character=stringArrayText[pos];
				if(pos%2!=0)
				{
					char x=Character.toUpperCase(character);
					stringArrayText[pos]=x;
				}
			}
			modificationText= String.valueOf(stringArrayText);
			System.out.println("Before Modification: " + operationString.getText());
			operationString.setText(modificationText);
			System.out.println("Modified String is: " + operationString.getText());
			
	case 3:
		
		System.out.println("Enter your TEXT ");
		operationString.setText(br.readLine());
		System.out.println("Before modification: "+operationString.getText());
		String withoutDuplicte=operationString.removeDuplicates(operationString.getText());
		operationString.setText(withoutDuplicte);
		System.out.println("After Modification: "+ operationString.getText());	
		break;
		default:
			System.out.println("Sorry invalid Choice");
			break;
		}

	}

}