/**
 * 
 */
package Lab3;

/**
 * @author subsil
 *
 */
public enum Months {
January,February,March
}
