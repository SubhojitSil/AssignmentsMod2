package Lab3;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class positiveString {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		int counter=0;
		BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the string that neegs to be checked");
		String text=br.readLine();
		positiveString positivestring= new positiveString();
		positivestring.checkPositive(text);
		
	}
void  checkPositive(String text)
	{
		int count=0;
		byte[] textArr=text.getBytes();
		int lengthOfText=textArr.length;
		for (int position=0; position<lengthOfText-1; position++)
		{
			if(textArr[position]>=textArr[position+1])
				count++;
		}
		if(count==0){
			System.out.println("Positive String");
		}
		else {
			System.out.println("Not a positive string");
		}
	}
	
}
   