/**
 * 
 */
package Lab3;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAccessor;
/**
 * @author subsil
 *
 */
public class Date {

	/**
	 * @param args
	 * @throws IOException 
	 * @throws ParseException 
	 */
	public static void main(String[] args) throws IOException, ParseException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		String date1,date2;
		System.out.println("Enter the Date 1 in format dd/mm/yyyy");
		date1=br.readLine();
		System.out.println("Enter the Date 1 in format dd/mm/yyyy");
		date2=br.readLine();
		
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		
		
		
		TemporalAccessor ld = dtf.parse(date1);
		LocalDate myDate1 = LocalDate.from(ld);
		TemporalAccessor ld2 = dtf.parse(date2);
		LocalDate myDate2 = LocalDate.from(ld2);
		
		LocalDate startDate = myDate1;
		LocalDate endDate =myDate2 ;
		Period span = startDate.until(endDate);
		
		System.out.println("number of days: " + span.getDays()); 
		System.out.println("number of months: " + span.getMonths());
		System.out.println("number of years: " + span.getYears());
		


	}
}
