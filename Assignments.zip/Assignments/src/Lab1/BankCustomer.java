package Lab1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class BankCustomer {
	private int accountnumber;
	private String name;
	private String accounttype;
	private double Balance;

	public int getAccountnumber() {
		return accountnumber;
	}

	public void setAccountnumber(int accountnumber) {
		this.accountnumber = accountnumber;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAccounttype() {
		return accounttype;
	}

	public void setAccounttype(String savings) {
		this.accounttype = savings;
	}

	public double getBalance() {
		return Balance;
	}

	public void setBalance(double balance) {
		Balance = balance;
	}

	public static void main(String[] args) throws NumberFormatException,
			IOException {
		int accountnumber;
		String name, accounttype;
		double balance;
		BankCustomer customer = new BankCustomer();
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter id");
		customer.setAccountnumber(Integer.parseInt(br.readLine()));
		System.out.println("Enter Customer Name");
		customer.setName(br.readLine());
		System.out.println("Enter opening balance");
		customer.setBalance(Double.parseDouble(br.readLine()));
		System.out.println("Enter Account Type\n1->savings\n2->Current  ");
		int ch = Integer.parseInt(br.readLine());

		switch (ch) {
		case 1:

			customer.setAccounttype("savings");
			break;
		case 2:

			customer.setAccounttype("current");
			break;
		default:
			System.out.println("Invalid Choice");

			break;
		}
		System.out.println("Customer  " + customer.getName() + " with  account number"
				+ customer.getAccountnumber() + " with  "
				+ customer.getAccounttype() + " account having Balance "
				+ customer.getBalance() + " has been generated");
	}
}
