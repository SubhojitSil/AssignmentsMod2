package Lab2;

public enum Gender {
	M, F
}
