package Lab2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Person {
	private String firstname;
	private String lastname;
	private Gender gender;
	private int age;
	private float weight;
	private long phoneNo;

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public Gender getGender() {
		return gender;
	}

	public void setGender(Gender gender) {
		this.gender = gender;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public float getWeight() {
		return weight;
	}

	public void setWeight(float weight) {
		this.weight = weight;
	}

	public long getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}

	public Person() {
	}

	public Person(String firstname, String lastname, Gender gender, int age,
			float weight, long phoneNo) {
		this.firstname = firstname;
		this.lastname = lastname;
		this.gender = gender;
		this.age = age;
		this.weight = weight;
		this.phoneNo = phoneNo;
	}

	public void displayDetails() {
		System.out.println("Person Details\n");
		System.out.println("_____________________");
		System.out.println("Last Name:  " + this.getFirstname());
		System.out.println("Last Name:  " + this.getLastname());
		System.out.println("Gender: " + this.getGender());
		System.out.println("Age:  " + this.getAge());
		System.out.println("Weight: " + this.getWeight());
		System.out.println("Phone No: " + this.getPhoneNo());
	}
}
