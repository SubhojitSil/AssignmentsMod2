package Lab2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class PersonMain {
	public static void main(String args[]) throws IOException {
		Person person = new Person();
		char ch;
		Gender gender = Gender.M;
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		/*
		 * System.out.println("Enter FIRST name");
		 * person.setFirstname(br.readLine());
		 * System.out.println("Enter LAST name");
		 * person.setLastname(br.readLine()); System.out.println("Enter AGE");
		 * person.setAge(Integer.parseInt(br.readLine()));
		 * System.out.println("Enter WEIGHT");
		 * person.setWeight(Float.parseFloat(br.readLine()));
		 * System.out.println("Enter Gender M->Male\n2->Female");
		 * ch=(char)br.read(); switch (ch) { case 'M': person.setGender('M');
		 * break; case 'F': person.setGender('F'); break; default:
		 * System.out.println("Invalid Input"); break; }
		 */

		System.out.println("Enter FIRST name");
		String firstName = br.readLine();
		System.out.println("Enter Last");
		String lastname = br.readLine();
		System.out.println("Enter Age ");
		int age = Integer.parseInt(br.readLine());
		System.out.println("Enter weight");
		float weight = Float.parseFloat(br.readLine());
		System.out.println("Enter Phone no.");
		long phoneNo = Long.parseLong(br.readLine());
		System.out.println("Enter Gender M->Male\nF->Female");
		ch = (char) br.read();
		switch (ch) {
		case 'M':
			gender = Gender.M;
			break;
		case 'F':
			gender = Gender.F;
			break;
		default:
			System.out.println("Invalid Input");
			break;
		}
		Person person1 = new Person(firstName, lastname, gender, age, weight,
				phoneNo);

		person1.displayDetails();
	}

}
