/**
 * 
 */
package Lab2;

/**
 * @author subsil
 *
 */
public class CommandLineArgument {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int number=Integer.parseInt(args[0]);
		if(number>=0){
			System.out.println("Positive Numbers");
		}
		else{
			System.out.println("Negative Number");
		}
		
	}

}
