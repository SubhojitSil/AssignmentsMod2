/**
 * 
 */
package Lab4;

import java.util.Random;

/**
 * @author subsil
 *
 */
public class Account extends Person {
	private long accNum;
	private double balance;
	private Person accHolder;

	public long getAccNum() {
		return accNum;
	}

	public void setAccNum() {
		Random randomNumber = new Random();
		this.accNum = randomNumber.nextInt(99999);
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public Person getAccHolder() {
		return accHolder;
	}

	public void setAccHolder(Person accHolder) {
		this.accHolder = accHolder;
	}

	void deposit(double amount) {
		this.balance = this.balance - amount;

	}

	void withDraw(double amount) {
		this.balance = this.balance - amount;

	}

	public String toString() {
	return("Name: " + getName() + "\nAccount Number: "
				+ getAccNum() + "\nAge:  " + getAge() + "\nBalance: "
				+ getBalance()+"\n***************************************");
		
		
	}
}
