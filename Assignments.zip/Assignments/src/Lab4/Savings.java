/**
 * 
 */
package Lab4;

/**
 * @author subsil
 *
 */
public class Savings extends Account{
	final double minimumBalance=1000;

	@Override
	void withDraw(double amount) {
		// TODO Auto-generated method stub
		//super.withDraw(amount);
double balance1=getBalance();
		
		if((balance1-amount)>minimumBalance)
		{
			setBalance(balance1-amount);;
		}
		else 
		{
			System.out.println("SORRY UNABLE TO PROCEED DUE TO INSUFFICIENT FUND");
			System.out.println("****************************************");
	}
	
	}
}


