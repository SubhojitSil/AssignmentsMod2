package com.cg.eis.service;

import com.cg.eis.bean.Employee;

public class EmployeeServiceOperations implements EmployeeServices {
	//Employee employee= new Employee();
	@Override
	public void getDetails(Employee employee) {
		// TODO Auto-generated method stub
     // int eid = employee.getEmpID();
    //  employee.setEmpID(eid);
      
      
       
	}

	@Override
	public void generateInsuranceScheme() {
		// TODO Auto-generated method stub

	}

	@Override
	public void displayDetails() {
		// TODO Auto-generated method stub

	}

	

}
