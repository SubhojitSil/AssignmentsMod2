/**
 * 
 */
package com.cg.eis.service;

import com.cg.eis.bean.Employee;

/**
 * @author subsil
 *
 */
public interface EmployeeServices {

void generateInsuranceScheme();
void displayDetails();
void getDetails(Employee employee);


}
